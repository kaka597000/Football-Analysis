# WCPP 单场双模型离线交接包

样本：2026-10-20销售日周二010，波尔图—埃因霍温；北京时间2026-10-21 03:00开球。
本包是原输入、两份实际JSON工件、原活动注册表、两份51×51矩阵、原冻结证据及源码检查点的副本。
source/对应配套GitHub检查点commit；清单内每个原件保留原路径、字节数、SHA256。
path-map.json单独登记路径映射，不改写原输入、工件或冻结记录。

## 复现命令

建议Python 3.12，先在独立环境安装source/handoff/requirements-replay.txt的固定依赖，然后运行：
`PYTHONDONTWRITEBYTECODE=1 python source/handoff/replay.py --bundle . --out /tmp/wcpp-offline-replay-new`

--out必须不存在。脚本验证manifest后调用原runtime/predict_active.py中的run，不调用生产冻结CLI。
历史时钟只在适配层还原至两份原输出各自的generated_at；实际重放时间另行记录。
脚本禁止socket连接、SQLite连接和子进程；不重新查询网页，不读取完整赛事库，不新增赛前冻结。
复现检查包括两份完整矩阵逐元素精确比较、矩阵哈希、Primary、比分轴、胜平负、大小球、工件及代码身份。

原统计比分两侧均1–1；综合人工第一比分2–1是独立轨，原记录保留，不伪装成模型数值输出。
欧冠训练比赛截止2026-09-10；统一库10月16日更新不代表活动参数随之重训。
原pair的data_freshness_notice属于当时发布层元数据，run不产生它；差异单列，不补造。

## 边界及文件

- manifest.json和SHA256SUMS：包内文件身份；SHA256SUMS不包含自身。
- database-audit-summary.json：独立实测数据库身份与更新时间证据；完整数据库未打包。
- originals/：原件逐字节副本；source/：独立源码检查点。
- validation/：本次导出后实际离线重放的派生日志及报告，不是原赛前日志。
- missing-and-scope.json：缺失项和有意缩小的范围，原始stdout/stderr未找到。

本包验证执行可复现性，不是新的赛前预测、不计命中率、不证明预测效果改善或模型晋级。
另一Cloud任务完成下载、验hash和独立重放后，才能确认跨环境复现成功；三路汇总尚未执行。
